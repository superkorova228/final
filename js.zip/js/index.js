// js/home.js
$(function(){
  // set year
  const y = new Date().getFullYear();
  $('#year').text(y);
});
