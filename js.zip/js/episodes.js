$(function(){
    $('a[href^="#"]').on('click', function(e){
        const target = $(this.getAttribute('href'));
        if(target.length){
            e.preventDefault();
            $('html,body').animate({scrollTop: target.offset().top - 70}, 400);
        }
    });
    

  let watchList = [];
  let sortAsc = true;
  const $tableBody = $('#watchTable tbody');
  const $searchBox = $('#searchBox');
  const editModal = new bootstrap.Modal($('#editModal')[0]);

  // CREATE
  $('#addForm').on('submit', function(e){
    e.preventDefault();
    const title = $('#episodeSelect').val();
    const date = $('#watchedDate').val();

    if(!title || !date) return;

    const item = {
      id: Date.now(),
      title,
      date
    };

    watchList.push(item);
    renderTable(watchList);
    this.reset();
    $('#episodeSelect').val('');

    $('html, body').animate({ scrollTop: $('#watchTable').offset().top }, 400);
  });

  // READ / RENDER
  function renderTable(list){
    $tableBody.empty();

    if(list.length === 0){
      $tableBody.append('<tr><td colspan="3" class="text-center text-muted">No episodes added yet.</td></tr>');
      return;
    }

    $.each(list, function(i, item){
      const row = $(`
        <tr data-id="${item.id}">
          <td>${item.title}</td>
          <td>${item.date}</td>
          <td>
            <button class="btn btn-sm btn-warning edit-btn me-2">Edit</button>
            <button class="btn btn-sm btn-danger delete-btn">Delete</button>
          </td>
        </tr>
      `);
      $tableBody.append(row.hide().slideDown(300));
    });
  }

  // DELETE
  $tableBody.on('click', '.delete-btn', function(){
    const id = $(this).closest('tr').data('id');
    if(confirm('Delete this episode from your list?')){
      $(this).closest('tr').fadeOut(300, function(){
        watchList = watchList.filter(i => i.id !== id);
        renderTable(watchList);
      });
    }
  });

  // OPEN EDIT MODAL
  $tableBody.on('click', '.edit-btn', function(){
    const id = $(this).closest('tr').data('id');
    const item = watchList.find(i => i.id === id);

    $('#editId').val(item.id);
    $('#editEpisodeTitle').val(item.title);
    $('#editDate').val(item.date);

    editModal.show();
  });

  // SAVE CHANGES
  $('#saveEditBtn').on('click', function(){
    const id = Number($('#editId').val());
    const newDate = $('#editDate').val();

    if(!newDate) return;

    const item = watchList.find(i => i.id === id);
    item.date = newDate;

    editModal.hide();
    renderTable(watchList);
  });

  // SEARCH
  $searchBox.on('input', function(){
    const term = $(this).val().toLowerCase();
    const filtered = watchList.filter(i => i.title.toLowerCase().includes(term));
    renderTable(filtered);
  });

  // SORT
  $('#sortBtn').on('click', function(){
    sortAsc = !sortAsc;
    watchList.sort((a, b) => a.title.localeCompare(b.title) * (sortAsc ? 1 : -1));
    renderTable(watchList);
  });


});
