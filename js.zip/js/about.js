$(function(){
    function validateEmail(email){
        return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
    }
    
    
    $('#contactForm').on('submit', function(e){
        e.preventDefault();
        const name = $('#name').val().trim();
        const email = $('#email').val().trim();
        const message = $('#message').val().trim();
        
        let ok = true;
        
        if(name.length < 2){
            ok = false;
            $('#name').addClass('is-invalid');
            $('#nameError').text('Please enter at least 2 characters.');
        } else {
            $('#name').removeClass('is-invalid');
            $('#nameError').text('');
        }
        
        if(!validateEmail(email)){
            ok = false;
            $('#email').addClass('is-invalid');
            $('#emailError').text('Enter a valid email address.');
        } else {
            $('#email').removeClass('is-invalid');
            $('#emailError').text('');
        }
        
        if(message.length < 10){
            ok = false;
            $('#message').addClass('is-invalid');
            $('#msgError').text('Message must be at least 10 characters.');
        } else {
            $('#message').removeClass('is-invalid');
            $('#msgError').text('');
        }
        
        if(ok){
            $('#formSuccess').fadeIn().delay(1200).fadeOut();
            $('#contactForm')[0].reset();
        }
    });
    
    $('#contactForm input, #contactForm textarea').on('input', function(){
        $(this).removeClass('is-invalid');
    });
});
