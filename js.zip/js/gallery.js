$(function(){
  const images = [
    {src: 'images/1.jpg', category: 'character', title: '1'},
    {src: 'images/2.jpg', category: 'fanart', title: '2'},
    {src: 'images/3.png', category: 'fanart', title: '3'},
    {src: 'images/4.jpg', category: 'character', title: '4'},
    {src: 'images/5.jpg', category: 'screenshot', title: '5'},
    {src: 'images/6.jpg', category: 'fanart', title: '6'},
    {src: 'images/7.jpg', category: 'character', title: '7'},
    {src: 'images/8.jpg', category: 'screenshot', title: '8'},
    {src: 'images/9.jpg', category: 'character', title: '9'},
    {src: 'images/10.jpg', category: 'screenshot', title: '10'},
    {src: 'images/11.jpg', category: 'fanart', title: '11'},
    {src: 'images/12.jpg', category: 'fanart', title: '12'},
    {src: 'images/13.jpg', category: 'character', title: '13'},
    {src: 'images/14.jpg', category: 'fanart', title: '14'}
  ];

  const $gallery = $('#gallery-container');
  const $lightbox = $('.lightbox');
  const $lightboxImg = $('#lightbox-img');
  let currentIndex = 0;
  let displayed = images.slice();


  function renderGallery(items){
    displayed = items;
    $gallery.empty();
    $.each(items, function(i, img){
      const item = $(`
        <div class="col-sm-6 col-md-4">
          <div class="gallery-item" data-index="${i}" data-category="${img.category}" data-src="${img.src}">
            <img src="${img.src}" alt="${img.title}">
          </div>
        </div>`);
      item.hide().appendTo($gallery).fadeIn(400);
    });
  }

  renderGallery(images);


  $('.filter-btn').on('click', function(){
    $('.filter-btn').removeClass('active');
    $(this).addClass('active');
    const filter = $(this).data('filter');
    let filtered = images;
    if(filter !== 'all'){
      filtered = images.filter(img => img.category === filter);
    }
    renderGallery(filtered);
  });


  $gallery.on('click', '.gallery-item img', function(){
    currentIndex = $(this).closest('.gallery-item').data('index');
    openLightbox(displayed[currentIndex].src);
  });

  function openLightbox(src){
    $lightboxImg.attr('src', src).css('opacity', 0);
    $lightbox.removeClass('d-none').hide().fadeIn(1000);
    $lightboxImg.animate({opacity: 1}, 1000);
  }

  function closeLightbox(){
    $lightbox.fadeOut(1000, function(){
      $(this).addClass('d-none');
    });
  }

  $('.btn-close').on('click', closeLightbox);
  $lightbox.on('click', function(e){
    if(e.target === this) closeLightbox();
  });


  $('.nav-arrow.next').on('click', function(){
    currentIndex = (currentIndex + 1) % displayed.length;
    switchImage(displayed[currentIndex].src);
  });

  $('.nav-arrow.prev').on('click', function(){
    currentIndex = (currentIndex - 1 + displayed.length) % displayed.length;
    switchImage(displayed[currentIndex].src);
  });

  function switchImage(src){
    $lightboxImg.fadeOut(200, function(){
      $(this).attr('src', src).fadeIn(300);
    });
  }


  $(document).on('keydown', function(e){
    if(e.key === 'Escape') closeLightbox();
    if(e.key === 'ArrowRight') $('.nav-arrow.next').trigger('click');
    if(e.key === 'ArrowLeft') $('.nav-arrow.prev').trigger('click');
  });
});
